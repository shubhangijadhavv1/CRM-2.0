/* global chrome */

// ─── State ───────────────────────────────────────────────────────────
let lastActivityAt = Date.now();
let lastHeartbeatSentAt = 0;
let authToken = '';
let apiBaseUrl = '';
let crmOrigin = '';
let systemIdleState = 'active'; // 'active' | 'idle' | 'locked'

const IDLE_AFTER_SECONDS = 60;
const IDLE_AFTER_MS = IDLE_AFTER_SECONDS * 1000;
const HEARTBEAT_PERIOD_MINUTES = 1;

// ─── Helpers ─────────────────────────────────────────────────────────
function inferApiBaseUrl(origin) {
  const o = String(origin || '').replace(/\/+$/, '');
  if (!o) return '';
  if (o === 'http://127.0.0.1:5173') return 'http://127.0.0.1:5000';
  if (o === 'http://localhost:5173') return 'http://localhost:5000';
  return o;
}

async function loadSession() {
  try {
    const s = await chrome.storage.local.get({ authToken: '', apiBaseUrl: '', crmOrigin: '' });
    if (!authToken && s.authToken) authToken = s.authToken;
    if (!apiBaseUrl && s.apiBaseUrl) apiBaseUrl = s.apiBaseUrl;
    if (!crmOrigin && s.crmOrigin) crmOrigin = s.crmOrigin;
  } catch { /* ignore */ }
}

async function saveSession() {
  try {
    await chrome.storage.local.set({ authToken, apiBaseUrl, crmOrigin });
  } catch { /* ignore */ }
}

// ─── chrome.idle — OS-level mouse/keyboard detection ─────────────────
// This is the PRIMARY idle source. It detects inactivity across the
// entire operating system (not just browser tabs).
chrome.idle.setDetectionInterval(IDLE_AFTER_SECONDS);

chrome.idle.onStateChanged.addListener((newState) => {
  const prevState = systemIdleState;
  systemIdleState = newState;

  if (newState === 'active') {
    lastActivityAt = Date.now();
    if (prevState !== 'active') {
      sendHeartbeat('system-became-active');
    }
  } else {
    // 'idle' or 'locked' — user has no mouse/keyboard activity
    sendHeartbeat('system-became-' + newState);
  }
});

// ─── Heartbeat ───────────────────────────────────────────────────────
async function sendHeartbeat(reason) {
  await loadSession();
  const now = Date.now();

  if (!apiBaseUrl || !authToken) {
    await chrome.storage.local.set({
      tokenPresent: false,
      systemIdleState,
      lastHeartbeatAt: 0,
      lastHeartbeatOk: false,
      lastHeartbeatStatus: 0,
      lastError: !authToken
        ? 'Not connected: open CRM and login so extension can capture your token.'
        : 'API URL not set.'
    });
    return;
  }

  if (now - lastHeartbeatSentAt < 4000 && reason !== 'state-change'
      && reason !== 'system-became-active'
      && reason !== 'system-became-idle'
      && reason !== 'system-became-locked') return;
  lastHeartbeatSentAt = now;

  // If system reports idle/locked, we know there's no mouse/keyboard.
  // Override lastActivityAt calculation: idle started at (now - idleFor).
  const effectiveLastActivity = (systemIdleState === 'active') ? lastActivityAt : Math.min(lastActivityAt, now - IDLE_AFTER_MS);

  try {
    const res = await fetch(`${apiBaseUrl}/api/activity/heartbeat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`
      },
      body: JSON.stringify({
        lastActivityAt: effectiveLastActivity,
        reason,
        systemIdleState,
        crmOrigin,
        extensionVersion: chrome.runtime.getManifest().version
      })
    });

    if (res.status === 401) {
      authToken = '';
      await saveSession();
    }

    await chrome.storage.local.set({
      tokenPresent: !!authToken,
      systemIdleState,
      lastHeartbeatAt: Date.now(),
      lastHeartbeatOk: res.ok,
      lastHeartbeatStatus: res.status,
      lastError: res.ok ? '' : `Heartbeat failed: HTTP ${res.status}`
    });
  } catch (e) {
    await chrome.storage.local.set({
      tokenPresent: !!authToken,
      systemIdleState,
      lastHeartbeatAt: Date.now(),
      lastHeartbeatOk: false,
      lastHeartbeatStatus: 0,
      lastError: 'Network error: cannot reach API server'
    });
  }
}

// ─── Lifecycle ───────────────────────────────────────────────────────
function startup() {
  loadSession();
  chrome.alarms.create('nexus-heartbeat', { periodInMinutes: HEARTBEAT_PERIOD_MINUTES });
  chrome.idle.setDetectionInterval(IDLE_AFTER_SECONDS);
}

chrome.runtime.onInstalled.addListener(startup);
chrome.runtime.onStartup.addListener(startup);

// ─── Alarm — periodic heartbeat + idle state verification ────────────
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== 'nexus-heartbeat') return;

  // Re-query the OS idle state on every tick to stay accurate even if
  // the onStateChanged event was missed (e.g. service worker reloaded).
  chrome.idle.queryState(IDLE_AFTER_SECONDS, (state) => {
    const prevState = systemIdleState;
    systemIdleState = state;
    if (state === 'active' && prevState !== 'active') {
      lastActivityAt = Date.now();
    }
    sendHeartbeat('interval');
  });
});

// ─── Messages from content scripts & popup ───────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;

  // Content script detected mouse/keyboard/scroll/click in a tab.
  // This supplements chrome.idle for tab-level granularity.
  if (msg.type === 'activity' && typeof msg.ts === 'number') {
    const wasIdle = (Date.now() - lastActivityAt) >= IDLE_AFTER_MS;
    lastActivityAt = msg.ts;
    systemIdleState = 'active';
    if (wasIdle) sendHeartbeat('state-change');
    return false;
  }

  // CRM tab sends its auth token so we can talk to the API.
  if (msg.type === 'auth' && typeof msg.token === 'string') {
    authToken = msg.token;
    if (typeof msg.crmOrigin === 'string') crmOrigin = msg.crmOrigin;
    apiBaseUrl = inferApiBaseUrl(crmOrigin);
    saveSession().then(() => sendHeartbeat('auth'));
    return false;
  }

  // Manual test from popup.
  if (msg.type === 'manualHeartbeat') {
    sendHeartbeat('manual')
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Popup requests current status.
  if (msg.type === 'getStatus') {
    loadSession()
      .then(() => chrome.storage.local.get({
        lastHeartbeatAt: 0,
        lastHeartbeatOk: false,
        lastHeartbeatStatus: 0,
        lastError: ''
      }))
      .then((local) => {
        const now = Date.now();
        const idleForMs = Math.max(0, now - lastActivityAt);
        const isIdle = systemIdleState !== 'active' || idleForMs >= IDLE_AFTER_MS;
        sendResponse({
          tokenPresent: !!authToken,
          apiBaseUrl,
          crmOrigin,
          idleAfterMs: IDLE_AFTER_MS,
          lastActivityAt,
          idleForMs,
          isIdle,
          systemIdleState,
          lastHeartbeatAt: Number(local.lastHeartbeatAt) || 0,
          lastHeartbeatOk: !!local.lastHeartbeatOk,
          lastHeartbeatStatus: Number(local.lastHeartbeatStatus) || 0,
          lastError: String(local.lastError || '')
        });
      })
      .catch(() => {
        sendResponse({
          tokenPresent: !!authToken,
          apiBaseUrl,
          crmOrigin,
          idleAfterMs: IDLE_AFTER_MS,
          lastActivityAt,
          idleForMs: 0,
          isIdle: false,
          systemIdleState,
          lastHeartbeatAt: 0,
          lastHeartbeatOk: false,
          lastHeartbeatStatus: 0,
          lastError: 'Internal error'
        });
      });
    return true;
  }

  return false;
});
