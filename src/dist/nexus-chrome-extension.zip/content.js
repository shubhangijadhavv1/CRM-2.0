/* global chrome */

const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'scroll', 'wheel', 'pointerdown', 'touchstart'];
const THROTTLE_MS = 1500;
let lastSentAt = 0;

function sendActivity() {
  const now = Date.now();
  if (now - lastSentAt < THROTTLE_MS) return;
  lastSentAt = now;
  try {
    chrome.runtime.sendMessage({ type: 'activity', ts: now });
  } catch { /* ignore */ }
}

for (const ev of ACTIVITY_EVENTS) {
  window.addEventListener(ev, sendActivity, { passive: true, capture: true });
}

function maybeSendAuthToken() {
  try {
    const token = localStorage.getItem('nexus_token');
    if (!token) return;
    chrome.runtime.sendMessage({
      type: 'auth',
      token,
      crmOrigin: location.origin,
      ts: Date.now()
    });
  } catch { /* ignore */ }
}

maybeSendAuthToken();
setInterval(maybeSendAuthToken, 30000);
