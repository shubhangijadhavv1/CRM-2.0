# Nexus CRM Activity Tracker (Chrome Extension)

## What it does
- Tracks keyboard/mouse/scroll activity across **all browser tabs**.
- Sends periodic heartbeats to your Nexus backend API so admins can see browser activity status.
- Idle timing is **fixed by the CRM/server** (users cannot customize idle timer).

## Install (unpacked)
1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select this folder: `browser-extension/`

## How it connects
1. Install the extension
2. Login to the CRM (the extension auto-captures your `nexus_token` from the CRM origin)
3. Click the extension icon to see **Connected / Not connected**

