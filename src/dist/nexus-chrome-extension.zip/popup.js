/* global chrome */

const statusPill = document.getElementById('statusPill');
const tokenState = document.getElementById('tokenState');
const lastHeartbeatEl = document.getElementById('lastHeartbeat');
const systemStateEl = document.getElementById('systemState');
const lastActivityEl = document.getElementById('lastActivity');
const idleForEl = document.getElementById('idleFor');
const idleThresholdEl = document.getElementById('idleThreshold');
const errorEl = document.getElementById('error');
const openCrmBtn = document.getElementById('openCrm');
const testBtn = document.getElementById('test');

function fmtAgo(ts) {
  if (!ts) return '—';
  const ms = Date.now() - ts;
  if (ms < 1500) return 'just now';
  const s = Math.floor(ms / 1000);
  if (s < 60) return s + 's ago';
  return Math.floor(s / 60) + 'm ago';
}

function fmtDuration(ms) {
  if (!ms || ms < 1000) return '0s';
  const s = Math.floor(ms / 1000);
  if (s < 60) return s + 's';
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return m + 'm ' + rem + 's';
}

function setPill(cls, text) {
  statusPill.className = 'pill ' + cls;
  statusPill.textContent = text;
}

function setSystemPill(state) {
  if (state === 'active') {
    systemStateEl.className = 'pill active-pill';
    systemStateEl.textContent = 'Active';
  } else if (state === 'locked') {
    systemStateEl.className = 'pill locked-pill';
    systemStateEl.textContent = 'Locked';
  } else {
    systemStateEl.className = 'pill idle-pill';
    systemStateEl.textContent = 'Idle';
  }
}

async function refresh() {
  errorEl.style.display = 'none';
  try {
    const st = await chrome.runtime.sendMessage({ type: 'getStatus' });

    tokenState.textContent = st.tokenPresent ? 'Captured' : 'Missing';
    lastHeartbeatEl.textContent = st.lastHeartbeatAt ? fmtAgo(st.lastHeartbeatAt) : '—';
    idleThresholdEl.textContent = Math.round((st.idleAfterMs || 60000) / 1000) + 's';

    setSystemPill(st.systemIdleState || 'active');
    lastActivityEl.textContent = st.lastActivityAt ? fmtAgo(st.lastActivityAt) : '—';
    idleForEl.textContent = st.isIdle ? fmtDuration(st.idleForMs) : 'Not idle';

    const hbFresh = st.lastHeartbeatAt && (Date.now() - st.lastHeartbeatAt) < 180000;

    if (!st.tokenPresent) {
      setPill('bad', 'Not connected');
    } else if (!st.lastHeartbeatOk) {
      setPill('warn', 'Token OK, API not syncing');
    } else if (!hbFresh) {
      setPill('warn', 'Connected (waiting heartbeat)');
    } else {
      setPill('ok', 'Connected');
    }

    if (st.lastError) {
      errorEl.textContent = st.lastError;
      errorEl.style.display = 'block';
    }
  } catch (e) {
    setPill('bad', 'Error');
    errorEl.textContent = String(e && e.message || e);
    errorEl.style.display = 'block';
  }
}

openCrmBtn.addEventListener('click', function () {
  chrome.runtime.sendMessage({ type: 'getStatus' }).then(function (st) {
    chrome.tabs.create({ url: (st && st.crmOrigin) || 'http://127.0.0.1:5173' });
  }).catch(function () {
    chrome.tabs.create({ url: 'http://127.0.0.1:5173' });
  });
});

testBtn.addEventListener('click', function () {
  chrome.runtime.sendMessage({ type: 'manualHeartbeat' }).catch(function () {});
  setTimeout(refresh, 500);
});

refresh();
setInterval(refresh, 5000);
